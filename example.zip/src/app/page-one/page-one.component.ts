import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-one',
  templateUrl: './page-one.component.html',
  styleUrls: ['./page-one.component.css']
})
export class PageOneComponent implements OnInit {

  public topmost: boolean;

  public messageFromChild: string;


  constructor() { }

  ngOnInit(): void {
    this.topmost = window.self == window.top;

    if (!this.topmost)
      window.parent.postMessage('Page One Open in Child', '*');

    window.addEventListener("message", (event:any) => {
      if (event.data) {
        this.messageFromChild = event.data;
      }
    });
  }

}
