import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-two',
  templateUrl: './page-two.component.html',
  styleUrls: ['./page-two.component.css']
})
export class PageTwoComponent implements OnInit {
  public topmost: boolean;

  constructor() { }

  ngOnInit(): void {
    this.topmost = window.self == window.top;

    if (!this.topmost)
      window.parent.postMessage('Page Two Open in Child', '*');


  }

}
